# C PATH — Android starter project

A dark-themed Android learning app starter for C programming.

## Included in this first milestone
- Native Android Java project
- Dark interface and Home / Learn / Practice / Quiz sections
- Starter lessons available offline
- C code editor
- Online C execution request through the Piston API
- GitHub Actions workflow to build and upload a debug APK

## Important compiler note
This starter currently provides **online execution** and **offline lessons/code editing**. It does not yet bundle a native offline C compiler. A real offline compiler needs a tested Android-compatible compiler engine (for example, a native toolchain built for supported Android ABIs). We should integrate and test that in a separate milestone rather than pretend offline execution already works.

## Build the APK on GitHub
1. Create a new GitHub repository named `C-PATH-Android`.
2. Upload the contents of this ZIP (upload the files inside the folder, not the ZIP itself).
3. Open the repository's **Actions** tab.
4. Select **Build C PATH APK**.
5. Tap **Run workflow** if it has not started automatically.
6. When the run succeeds, open it and download the `C_PATH-debug-apk` artifact.
7. Extract the artifact ZIP to get `app-debug.apk`.

## Build locally
Requires Android SDK, JDK 17 and Gradle 8.9:
`gradle assembleDebug`

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Notes
- The online compiler requires internet access and depends on the availability and policies of the Piston service.
- Do not send secrets or personal information in code submitted to a third-party execution service.
- This is an unsigned debug APK suitable for testing, not a Play Store release.
