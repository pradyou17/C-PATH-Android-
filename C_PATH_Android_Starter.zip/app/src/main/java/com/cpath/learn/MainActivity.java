package com.cpath.learn;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final int BG = Color.rgb(9,15,29), PANEL = Color.rgb(19,29,48);
    private final int CYAN = Color.rgb(53,198,244), WHITE = Color.rgb(238,244,255);
    private final int MUTED = Color.rgb(160,176,199);
    private LinearLayout content;
    private EditText codeEditor;
    private TextView output;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setBackgroundColor(BG);
        TextView brand = new TextView(this);
        brand.setText("C PATH   •   LEARN C THE EASY WAY");
        brand.setTextColor(CYAN); brand.setTextSize(17); brand.setTypeface(null, Typeface.BOLD);
        brand.setPadding(20,22,16,16);
        page.addView(brand);
        HorizontalScrollView navScroll = new HorizontalScrollView(this);
        navScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout nav = new LinearLayout(this);
        nav.setPadding(12,0,12,12);
        for (String tab : new String[]{"Home","Learn","Practice","Quiz"}) {
            Button b = button(tab);
            b.setOnClickListener(v -> show(tab));
            nav.addView(b);
        }
        navScroll.addView(nav); page.addView(navScroll);
        ScrollView scroll = new ScrollView(this);
        content = new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(16,8,16,28);
        scroll.addView(content);
        page.addView(scroll, new LinearLayout.LayoutParams(-1,0,1));
        setContentView(page);
        show("Home");
    }

    private GradientDrawable rounded(int color) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(22); return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setPadding(2,6,2,6); return t;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setTextColor(WHITE);
        b.setAllCaps(false); b.setTextSize(14); b.setBackground(rounded(Color.rgb(31,55,79)));
        return b;
    }
    private void card(String title, String body) {
        LinearLayout box = new LinearLayout(this); box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(16,12,16,14); box.setBackground(rounded(PANEL));
        TextView h = text(title,18,CYAN,true); TextView p = text(body,15,WHITE,false);
        box.addView(h); box.addView(p);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.bottomMargin=12;
        content.addView(box,lp);
    }
    private void show(String tab) {
        content.removeAllViews();
        if (tab.equals("Home")) {
            content.addView(text("Welcome to C PATH 👋",25,WHITE,true));
            content.addView(text("Learn C programming step by step, from your first program to functions and pointers.",16,MUTED,false));
            card("Your learning path","1. Introduction to C\n2. Variables and data types\n3. Operators and expressions\n4. Decision making\n5. Loops\n6. Arrays and strings\n7. Functions\n8. Pointers\n9. Structures and unions");
            card("Learn anywhere","Lessons and saved code are available offline. Internet is needed for the online compiler.");
            Button learn=button("Start learning"); learn.setOnClickListener(v->show("Learn")); content.addView(learn);
        } else if (tab.equals("Learn")) {
            content.addView(text("C Programming Lessons",23,WHITE,true));
            String[][] lessons = {
                {"1. What is C?","C is a general-purpose programming language. It is widely used for system software, embedded systems and learning programming fundamentals."},
                {"2. Structure of a C program","A basic C program includes header files, the main() function and statements. Example: #include <stdio.h> followed by int main(void) { printf(\"Hello\"); return 0; }"},
                {"3. Variables and data types","A variable is a named memory location. Common types include int for whole numbers, float for decimal values, char for a character and double for more precise decimal values."},
                {"4. Operators","Arithmetic operators include +, -, *, / and %. Relational operators compare values. Logical operators are &&, || and !."},
                {"5. Decision making","Use if, else if and else to run code based on a condition. Use switch when selecting between fixed cases."},
                {"6. Loops","for, while and do-while repeat statements. Choose a loop based on when the condition should be checked."},
                {"7. Arrays and strings","An array stores multiple values of the same type. A C string is a character array ending with the null character '\\0'."},
                {"8. Functions","Functions divide a program into reusable parts. A function can accept parameters and return a value."},
                {"9. Pointers","A pointer stores the memory address of another variable. & obtains an address and * accesses the value at an address."},
                {"10. Structures","A structure groups related variables, possibly of different data types, under one name."}
            };
            for (String[] l: lessons) card(l[0],l[1]);
        } else if (tab.equals("Practice")) {
            content.addView(text("C Code Practice",23,WHITE,true));
            content.addView(text("Write a C program below. Online execution sends your code to the Piston code execution service. Do not enter passwords or private information.",14,MUTED,false));
            codeEditor = new EditText(this); codeEditor.setText("#include <stdio.h>\n\nint main(void) {\n    printf(\"Hello, C PATH!\\\\n\");\n    return 0;\n}");
            codeEditor.setTextColor(WHITE); codeEditor.setHintTextColor(MUTED); codeEditor.setTextSize(14);
            codeEditor.setTypeface(Typeface.MONOSPACE); codeEditor.setGravity(Gravity.TOP|Gravity.START);
            codeEditor.setPadding(14,14,14,14); codeEditor.setMinLines(12);
            codeEditor.setBackground(rounded(Color.rgb(13,22,37)));
            content.addView(codeEditor,new LinearLayout.LayoutParams(-1,-2));
            Button run=button("Run online"); run.setOnClickListener(v->runOnline()); content.addView(run);
            output=text("Output will appear here.",14,WHITE,false); output.setTypeface(Typeface.MONOSPACE);
            output.setPadding(14,14,14,14); output.setBackground(rounded(PANEL)); content.addView(output);
            card("Offline mode","You can read lessons and edit your code offline. A full native offline C compiler is not included in this first project scaffold; it will be integrated and tested as a separate build step.");
        } else {
            content.addView(text("Quick C Quiz",23,WHITE,true));
            card("Question 1","Which function is the usual entry point of a C program?\n\nA) start()\nB) main()\nC) run()\nD) printf()");
            Button answer=button("Show answer"); answer.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle("Correct answer").setMessage("B) main()").setPositiveButton("OK",null).show()); content.addView(answer);
            card("Question 2","Which format specifier is commonly used to print an int?\n\nA) %c\nB) %f\nC) %d\nD) %s");
            Button a2=button("Show answer"); a2.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle("Correct answer").setMessage("C) %d").setPositiveButton("OK",null).show()); content.addView(a2);
            card("Keep practising","More questions, scoring and progress tracking will be added in the next milestones.");
        }
    }

    private void runOnline() {
        if (codeEditor == null) return;
        String source = codeEditor.getText().toString();
        output.setText("Running...");
        executor.execute(() -> {
            HttpURLConnection conn = null;
            try {
                URL url = new URL("https://emkc.org/api/v2/piston/execute");
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST"); conn.setConnectTimeout(15000); conn.setReadTimeout(20000);
                conn.setDoOutput(true); conn.setRequestProperty("Content-Type","application/json");
                JSONObject body = new JSONObject();
                body.put("language","c"); body.put("version","*");
                JSONArray files = new JSONArray(); JSONObject file = new JSONObject();
                file.put("name","main.c"); file.put("content",source); files.put(file); body.put("files",files);
                try(OutputStream os=conn.getOutputStream()){os.write(body.toString().getBytes(StandardCharsets.UTF_8));}
                int status=conn.getResponseCode();
                InputStream is=status>=200 && status<300?conn.getInputStream():conn.getErrorStream();
                ByteArrayOutputStream buffer=new ByteArrayOutputStream();
                byte[] data=new byte[4096]; int n; while((n=is.read(data))!=-1) buffer.write(data,0,n);
                JSONObject result=new JSONObject(buffer.toString("UTF-8"));
                JSONObject run=result.optJSONObject("run");
                String message=run==null?result.toString(2):"Exit code: "+run.optInt("code")+"\n\n"+run.optString("output");
                if(run!=null && run.optString("stderr").length()>0) message+="\n\nErrors:\n"+run.optString("stderr");
                final String shown=message;
                runOnUiThread(()->output.setText(shown));
            } catch(Exception e) {
                runOnUiThread(()->output.setText("Could not run code online.\nCheck your internet connection and try again.\n\n"+e.getMessage()));
            } finally { if(conn!=null) conn.disconnect(); }
        });
    }
    @Override protected void onDestroy(){ super.onDestroy(); executor.shutdownNow(); }
}
